<div id="bannerpage">
    <div class="container">
        <div class="row">
            <div class="col-md">
                <div class="text-banner text-center">
                    <div class="headtext">Belajar HTML</div>
                    <p class="childtext">Menguasai HTML Dasar Web Programming</p>
                </div>
            </div>
        </div>
    </div>
</div>