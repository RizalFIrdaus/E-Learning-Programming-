




<?php $__env->startSection('content'); ?>
<?php $__env->startSection('headtext','Tutorial Javascript Dasar'); ?>
<?php $__env->startSection('childtext','Menguasai Dasar Pemrograman Javascript'); ?>

<?php $__currentLoopData = $materi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="container">
    <div id="video">
        <div class="row">
            <div class="col-md-10">
                <video
                id="my-video"
                class="video-js vjs-fluid"
                controls
                preload="auto"
                width="920"
                data-setup="{}"
            >
                <source src="<?php echo e(asset('upload/video/'.$mat->embed_vid)); ?>" type="video/mp4" />
                <p class="vjs-no-js">
                To view this video please enable JavaScript, and consider upgrading to a
                web browser that
                <a href="https://videojs.com/html5-video-support/" target="_blank"
                    >supports HTML5 video</a
                >
                </p>
            </video>
            </div> 
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-2">
                <div class="card self-card">
                    <div class="card-header">
                      List Materi
                    </div>
                    <ul class="list-group list-group-flush">
                        <?php $__currentLoopData = $paginatemateri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paginate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item text-center">
                            <a href="<?php echo e(url('/materi/js?page='.$loop->iteration)); ?>">
                                <div class="card-list text-center">
                                    <?php echo e($paginate->list_materi); ?>

                                </div>
                            </a> 
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </ul>
                  </div>
            </div>
        </div>
<?php $__currentLoopData = $materi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row py-5">
            <div class="col-md-10">
                <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                    <li class="nav-item" role="presentation">
                      <button class="nav-link active" id="pills-desc-tab" data-bs-toggle="pill" data-bs-target="#pills-desc" type="button" role="tab" aria-controls="pills-desc" aria-selected="true">Description</button>
                    </li>
                    <li class="nav-item" role="presentation">
                      <button class="nav-link" id="pills-tools-tab" data-bs-toggle="pill" data-bs-target="#pills-tools" type="button" role="tab" aria-controls="pills-tools" aria-selected="false">Tools</button>
                    </li>
                  </ul>
                  <div class="tab-content" id="pills-tabContent">
                    <div class="tab-pane fade show active" id="pills-desc" role="tabpanel" aria-labelledby="pills-desc-tab">
                        <div class="row">
                            <div class="col-md">
                                <div class="text-pane">
                                    <p><?php echo e($mat->desc_vid); ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-9">
                                <div class="expert">
                                    <h1>Tutor Expert</h1>
                                    <div class="row">
                                        <?php $__currentLoopData = $photo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-4">
                                            <img src="<?php echo e(asset('/img/'.$p->img)); ?>" class="rounded-circle">
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md d-flex justify-content-center align-items-start flex-column">
                                            <div class="row">
                                                <div class="col-md">
                                                    <h2 class="head-expert"><?php echo e($mat->tutor); ?></h2>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md">
                                                    <p class="child-expert"><?php echo e($mat->title_tutor); ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>  
                    </div>
                    
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="tab-pane fade" id="pills-tools" role="tabpanel" aria-labelledby="pills-tools-tab">
                       <div class="row">
                        <?php $__currentLoopData = $tools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <div class="col-md-3 text-center">
                               <div class="tools">
                                  <img src="<?php echo e(asset('/img/'.$tool->img)); ?>"  class="rounded-circle">
                                  <p><?php echo e($tool->nama); ?></p>
                                  <a href="<?php echo e($tool->link); ?>" class="btn btn-primary">Download</a>
                               </div>
                           </div>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </div>
                    </div>         
                  </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md">
                <div id="disqus_thread"></div>
            </div>
        </div>
    </div>
</div>


<?php echo $__env->make('layouts.footerpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.navbar-page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app-page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\example-app\resources\views/pages/js.blade.php ENDPATH**/ ?>