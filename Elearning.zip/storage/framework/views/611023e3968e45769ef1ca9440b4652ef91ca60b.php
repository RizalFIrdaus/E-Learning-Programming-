
<?php $__env->startSection('judul','MATERI HTML'); ?>
<?php $__env->startSection('title','html'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
      <div class="col-md">
        <a href="<?php echo e(route('create_html')); ?>" class="btn btn-primary my-2">Insert Materi</a>
        <table class="table table-hover">
         
          <thead>
            <tr>
              <th scope="col">id</th>
              <th scope="col">embed_vid</th>
              <th scope="col">desc_vid</th>
              <th scope="col">list_materi</th>
              <th scope="col">tutor</th>
              <th scope="col">title_tutor</th>
              <th scope="col">img</th>
              <th scope="col">edit</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $materi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $html): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <th scope="row"><?php echo e($loop->iteration); ?></th>
              <td><?php echo e($html->embed_vid); ?></td>
              <td>....</td>
              <td><?php echo e($html->list_materi); ?></td>
              <td><?php echo e($html->tutor); ?></td>
              <td><?php echo e($html->title_tutor); ?></td>
              <td><?php echo e($html->img); ?></td>
              <td class="d-flex">
                  <form action="/admin/materi/html/edit/<?php echo e($html->id); ?>">
                    <button class="btn btn-primary mx-1">Update</button>
                  </form>
                  <form action="/admin/materi/html/<?php echo e($html->id); ?>" method="POST">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('delete'); ?>
                      <button class="btn btn-danger mx-1">Delete</button>
                  </form>
                </td>
            </tr>
          </tbody>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
      </div>
    </div>
  </div>    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\example-app\resources\views/admin/html/html.blade.php ENDPATH**/ ?>