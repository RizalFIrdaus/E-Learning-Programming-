
<?php $__env->startSection('judul','MATERI CSS'); ?>
<?php $__env->startSection('title','css'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <form action="/admin/materi/css/insert" method="POST" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div class="my-4 input-group row justify-content-center">
            <span class="input-group-text col-md-1" id="basic-addon1">ID</span>
            <div class="col-md-6">
                <input type="text" class="form-control" name="id"  placeholder="Auto Increment" aria-label="Username" aria-describedby="basic-addon1" disabled>
            </div>
          </div>
          <div class="my-4 row justify-content-center">
            <span class="input-group-text col-md-1" id="basic-addon1">DESC VIDEO</span>
            <div class="col-md-6">
                <textarea class="form-control" id="desc" name="desc_vid" rows="3" placeholder="Describe about the video..."></textarea>
              </div>
          </div>
          <div class="my-4 row justify-content-center">
            <span class="input-group-text col-md-1" id="basic-addon1">TITLE VIDEO</span>
            <div class="col-md-6">
                <input type="text" class="form-control" name="list_materi" placeholder="Title video in list materi" aria-label="Username" aria-describedby="basic-addon1">
            </div>
          </div>
          <div class="my-4 row justify-content-center">
            <label class="input-group-text col-md-1" for="inputGroupSelect01">TUTOR EXPERT</label>
            <div class="col-md-6">
              <select class="form-select form-control" id="inputGroupSelect01" name="tutor">
                <option selected>Pilih Tutor...</option>
                <?php $__currentLoopData = $tutor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($t->tutor); ?>"><?php echo e($t->tutor); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
          </div>
          <div class="my-4 row justify-content-center">
            <label class="input-group-text  col-md-1" for="inputGroupFile02">Upload Video</label>
            <div class="col-md-6">
               <input type="file" class="form-control" id="inputGroupFile02" name="embed_vid">
            </div>
          </div>
          <div class="my-4 row justify-content-center">
            <a class="col-md-1 btn btn-danger" href="<?php echo e(route('materi_css')); ?>">Back</a>
            <div class="col-md-6"> 
              <button class="col-md-1 btn btn-primary">Insert</button>
            </div>
         </div>
        </form>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\example-app\resources\views/admin/css/insert.blade.php ENDPATH**/ ?>